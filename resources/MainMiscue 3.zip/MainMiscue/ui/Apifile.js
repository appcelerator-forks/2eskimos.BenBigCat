Ti.include('/MainMiscue/ui/loadingScreen.js');

//API request
function createApi(url, strng, text1, text2, flag, modal, apiCount, menuItemKey, button_Id, audioFileName, fontcolour, backcolour, pagefontfamily, isPageName, tableView, sessionCount, fileName, loopEnds, submitSession) {
	var xmldata;
	var loginReq = Ti.Network.createHTTPClient();
	/*  loginReq.clearCookies('https://www.miscue.co.uk/iglooapi/apirequest.aspx');
	 loginReq.cache = false;
	 loginReq.setRequestHeader('Cache-Control','no-cache');
	 loginReq.setRequestHeader('Cache-Control','no-store'); */

	if (flag == 7) {
		if (audioFileName != 'null') {
			if (Ti.Platform.osname != 'android') {
				audioFileName = Titanium.Filesystem.getFile(Ti.Filesystem.tempDirectory, audioFileName);
			} else {
				var audioDir = Titanium.Filesystem.getFile(Titanium.Filesystem.externalStorageDirectory, "Miscue");
				audioFileName = Ti.Filesystem.getFile(audioDir.resolve(), audioFileName);
			}
			var var1 = 'requestXML';
			var name = 'myFile';
			var filename = 'b.b64';
			var boundary = '-------------------------301503177511666';
			var header = "--" + boundary + "\r\n" + "Content-Disposition: form-data;  name=\"requestXML\"\r\n\r\n" + strng + "\r\n\r\n";

			header += "--" + boundary + "\r\n";
			header += "Content-Disposition: form-data; name=\"" + name + "\";";
			header += " filename=\"" + filename + "\"\r\n";
			header += "Content-Type: application/octet-stream\r\n\r\n";
			var content = audioFileName.read();
			content = Ti.Utils.base64encode(content);
			var fullContent = header + content + "\r\n--" + boundary;
			loginReq.open("POST", url);

			loginReq.setRequestHeader('enctype', 'multipart/form-data');
			loginReq.setRequestHeader("Content-type", "multipart/form-data;boundary=\"" + boundary + "\"");
			loginReq.setRequestHeader("Content-Length", fullContent.length);
			loginReq.send(fullContent);

		} else {
			loginReq.open("POST", url);
			Ti.API.log("Req url of save session:: ", url);
			var param = {
				"requestXML" : strng
			};
			Ti.API.log("Req param at save session:: ", strng);
			loginReq.send(param);
		}
	} else if (flag == 5) {
		if (fileName != 'null') {
			if (Ti.Platform.osname != 'android') {
				fileName = Titanium.Filesystem.getFile(Ti.Filesystem.tempDirectory, fileName);
			} else {
				var audioDir = Titanium.Filesystem.getFile(Titanium.Filesystem.externalStorageDirectory, "Miscue");
				fileName = Ti.Filesystem.getFile(audioDir.resolve(), fileName);
			}
			var name = 'myFile';
			var filename = 'b.b64';
			var boundary = '-------------------------301503177511666';
			var header = "--" + boundary + "\r\n" + "Content-Disposition: form-data;  name=\"requestXML\"\r\n\r\n" + strng + "\r\n\r\n";

			header += "--" + boundary + "\r\n";
			header += "Content-Disposition: form-data; name=\"" + name + "\";";
			header += " filename=\"" + filename + "\"\r\n";
			header += "Content-Type: application/octet-stream\r\n\r\n";
			var content = fileName.read();
			content = Ti.Utils.base64encode(content);
			var fullContent = header + content + "\r\n--" + boundary;
			loginReq.open("POST", url);

			loginReq.setRequestHeader('enctype', 'multipart/form-data');
			loginReq.setRequestHeader("Content-type", "multipart/form-data;boundary=\"" + boundary + "\"");
			loginReq.setRequestHeader("Content-Length", fullContent.length);
			loginReq.send(fullContent);

		} else {
			loginReq.open("POST", url);
			var param = {
				"requestXML" : strng
			};
			loginReq.send(param);

		}
	} else {
		loginReq.open("POST", url);
		var param = {
			"requestXML" : strng
		};
		loginReq.send(param);

		// Ti.API.log("Book request api result is :: ", responses.toString());
		Ti.API.log("Api request param is :: ", param);

	}
	loginReq.onload = function() {
		xmldata = this.responseText;
		if (flag === 2) {
			Ti.API.log("XML data for flag==2 is :: ", xmldata);
			getGroupLearner(xmldata, text1, text2, apiCount, modal);
			//miscueMenuPage.js (Line No- 616)
		} else if (flag == 3) {
			Ti.API.log("XML data for flag==3 is :: ", xmldata);
			getLanguage(xmldata, text1);
			//Login.js(line no -645)
		} else if (flag == 4) {
			Ti.API.log("XML data for flag==4 is :: ", xmldata);
			createBooksTest(xmldata, text1, text2, modal, apiCount, menuItemKey, button_Id);
			//miscueMenuPage.js(line No - 717)
		} else if (flag == 5) {
			Ti.API.log("XML data for flag==5 is :: ", xmldata);
			createSavePendingMiscueSessionToServer(xmldata, text2, menuItemKey, modal, apiCount, sessionCount, button_Id, audioFileName, fontcolour, backcolour, pagefontfamily, isPageName, tableView, text1, loopEnds, submitSession);
			//sessionBookPage.js(line No-291)
		} else if (flag == 7) {
			Ti.API.log("XML data for flag==7 is :: ", xmldata);
			SaveMiscueSessionToServer(xmldata, text2, apiCount, modal, text1, menuItemKey, button_Id);
			//sessionBookPage.js(line No-291)
		} else if (flag == 1) {
			Ti.API.log("XML data for flag==1 is :: ", xmldata);
			callback(xmldata, text1, text2, apiCount, modal);
			//Login.js(line no-700)
		}

	};
	loginReq.onerror = function(e) {
		if (flag == 5) {
			modal.touchEnabled = true;
		}
		var labelArray = new Array();
		labelArray['title'] = ['Alert', 'Alert'];
		labelArray['message'] = ['network_Not_Found', 'Network not found'];
		labelArray[1] = ['Ok', 'OK'];
		var dialog = createLocalizedAlertDialog(labelArray, text1);
		dialog.show();
		if (flag == 2) {
			dialog.addEventListener('click', function(e) {
				if (e.index == 0) {
					var miscuewindow = tt.ui.createmiscueMenuPage(text1, text2, apiCount);
					miscuewindow.open();
					modal.close();
				}
			});
		}
		if (flag == 4) {
			dialog.addEventListener('click', function(e) {
				if (e.index == 0) {
					var miscuewindow = tt.ui.createmiscueMenuPage(text1, text2, apiCount);
					miscuewindow.open();
					modal.close();
				}
			});
		}
		if (flag == 1) {
			var db = Titanium.Database.open('Miscue');
			var loginIdRow = db.execute('SELECT userid FROM Login WHERE username = ?', text1);
			if (loginIdRow.rowCount > 0) {
				var loginUserId = loginIdRow.fieldByName('userid');
				loginIdRow.close();
				var homescreencheckrow = db.execute('SELECT * FROM UserMenuItem WHERE userId=?', loginUserId);
				if (homescreencheckrow.rowCount > 0) {
					homescreencheckrow.close();
					db.close();
					var homeScreenWin = tt.ui.createHomeScreen(text1);
					homeScreenWin.open();
					modal.close();
				}
			}
			modal.touchEnabled = true;
		}
		if (flag == 7) {
			if (menuItemKey == 'search') {
				var menuItemKeys = 'miscueanalysis';
				var searchSession = tt.ui.createsearchSession(text1, text2, button_Id, menuItemKeys);
				searchSession.open();
				modal.close();
			} else {
				var menuItemKeys = 'miscueanalysis';
				var miscuewindow = tt.ui.createmiscueMenuPage(text1, button_Id, menuItemKeys);
				miscuewindow.open();
				modal.close();
			}
		}
		hideActivity();

	};

	loginReq.setTimeout(40000);
}

