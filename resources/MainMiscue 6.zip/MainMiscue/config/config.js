/**
* Appcelerator Titanium Platform
* Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
* Licensed under the terms of the Apache Public License
* Please see the LICENSE included with this distribution for details.
**/

//make a copy of this file as config.js, and add your Twitter xAuth-enabled keys here
tt.config = {
	consumer_key: 'SVVOGeBDkfkDqhKLrnw',
	consumer_secret: 'ne3czav3B5y9C0kpS3RWW4SGqosy1wQ7ggnLH6uNBiY'
};